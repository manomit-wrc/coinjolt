module.exports = {
	accessKeyId: 'AKIAIDL6RATW4RXE5ZLQ',
	secretAccessKey: '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',
	senderEmail: 'support@coinjolt.com',
	S3_URL: 'https://s3.amazonaws.com/coinjoltdev2018/'
};